#pragma once
int num(char);