#pragma once
int WSymb(char);