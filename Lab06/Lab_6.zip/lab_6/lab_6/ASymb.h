#pragma once
int ASymb(char);